import max7219.led as led 
import RPi.GPIO as GPIO
import time
x = 0
GPIO.setmode(GPIO.BCM)
GPIO.setup(17,GPIO.IN, pull_up_down=GPIO.PUD_UP)

device = led.matrix()

while (True):
	if x == 0:
		device.show_message("Belajar raspberry  pi")
		x = x + 1
	if x == 2:
		device.show_message("Menggunakan bahasa python")
		x = x + 1
	if x == 4:
		device.show_message("Aplikasi kontrol Running Text")
		x = x + 1
	if x == 6:
		x = -1
	InputValue = GPIO.input(17)
	if (InputValue == False):
		x = x + 1
	print (x)
	time.sleep(0.3)
	
